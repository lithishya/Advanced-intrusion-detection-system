Note that the following fields have been changed from symbolic to continuous, because the data
has been sufficiently represented as integers:

- land
- logged_in
- is_host_login
- is_guest_login