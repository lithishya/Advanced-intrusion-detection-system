// Chatbot functionality for Network Intrusion Detection System
class SecurityChatbot {
    constructor() {
        this.messageHistory = [];
        this.isOpen = false;
        this.isInitialized = false;
        this.isLoading = false;
        this.topicButtons = [
            { id: 'attack-types', label: 'Common Attack Types', icon: 'fa-bug' },
            { id: 'security-basics', label: 'Security Basics', icon: 'fa-shield-alt' },
            { id: 'model-explain', label: 'How Model Works', icon: 'fa-brain' },
            { id: 'troubleshoot', label: 'Troubleshooting', icon: 'fa-wrench' }
        ];
    }

    init() {
        if (this.isInitialized) return;
        
        // Create chatbot HTML structure
        this.createChatbotUI();
        
        // Set up event listeners
        this.setupEventListeners();
        
        // Add welcome message
        this.addMessage("bot", "Hello! I'm your Security Assistant. I can help you understand network threats, explain alerts, and guide you through the system. How can I help you today?");
        
        this.isInitialized = true;
    }

    createChatbotUI() {
        // Create chatbot button
        const chatButton = document.createElement('div');
        chatButton.id = 'chat-button';
        chatButton.innerHTML = '<i class="fas fa-robot"></i>';
        chatButton.setAttribute('title', 'Security Assistant');
        document.body.appendChild(chatButton);
        
        // Create chatbot container
        const chatContainer = document.createElement('div');
        chatContainer.id = 'chat-container';
        chatContainer.className = 'chat-closed';
        
        // Create topic buttons HTML
        const topicButtonsHTML = this.topicButtons.map(button => 
            `<button id="${button.id}" class="topic-button">
                <i class="fas ${button.icon}"></i>
                ${button.label}
            </button>`
        ).join('');
        
        chatContainer.innerHTML = `
            <div class="chat-header">
                <div class="chat-title">
                    <i class="fas fa-shield-alt"></i>
                    Security Assistant
                </div>
                <div class="chat-controls">
                    <button id="chat-minimize" title="Minimize"><i class="fas fa-minus"></i></button>
                    <button id="chat-close" title="Close"><i class="fas fa-times"></i></button>
                </div>
            </div>
            <div class="topic-buttons-container">
                ${topicButtonsHTML}
            </div>
            <div class="chat-messages" id="chat-messages"></div>
            <div class="chat-input-container">
                <textarea id="chat-input" placeholder="Ask me about security or detected threats..."></textarea>
                <button id="chat-send" title="Send"><i class="fas fa-paper-plane"></i></button>
            </div>
            <div class="chat-suggestions">
                <button class="suggestion-chip" data-query="What is an intrusion detection system?">What is an IDS?</button>
                <button class="suggestion-chip" data-query="Explain the latest alert">Explain alert</button>
                <button class="suggestion-chip" data-query="How to interpret model explanation?">Interpret model</button>
                <button class="suggestion-chip" data-query="Best practices for network security">Security tips</button>
            </div>
        `;
        
        document.body.appendChild(chatContainer);
        
        // Add Font Awesome for icons
        if (!document.getElementById('fontawesome-css')) {
            const fontAwesome = document.createElement('link');
            fontAwesome.id = 'fontawesome-css';
            fontAwesome.rel = 'stylesheet';
            fontAwesome.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css';
            document.head.appendChild(fontAwesome);
        }
        
        // Add chatbot styles
        this.addChatbotStyles();
    }
    
    addChatbotStyles() {
        const styleEl = document.createElement('style');
        styleEl.innerHTML = `
            #chat-button {
                position: fixed;
                bottom: 20px;
                right: 20px;
                width: 60px;
                height: 60px;
                background-color: #3498db;
                color: white;
                border-radius: 50%;
                display: flex;
                justify-content: center;
                align-items: center;
                cursor: pointer;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
                z-index: 1000;
                font-size: 24px;
                transition: all 0.3s ease;
            }
            
            #chat-button:hover {
                background-color: #2980b9;
                transform: scale(1.05);
            }
            
            #chat-container {
                position: fixed;
                bottom: 100px;
                right: 20px;
                width: 350px;
                height: 500px;
                background-color: white;
                border-radius: 10px;
                overflow: hidden;
                display: flex;
                flex-direction: column;
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
                z-index: 999;
                transition: all 0.3s ease;
            }
            
            .chat-closed {
                opacity: 0;
                transform: translateY(20px) scale(0.9);
                pointer-events: none;
            }
            
            .chat-open {
                opacity: 1;
                transform: translateY(0) scale(1);
                pointer-events: all;
            }
            
            .chat-header {
                background-color: #2c3e50;
                color: white;
                padding: 15px;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            
            .chat-title {
                font-weight: bold;
                display: flex;
                align-items: center;
                gap: 8px;
            }
            
            .chat-controls {
                display: flex;
                gap: 5px;
            }
            
            .chat-controls button {
                background: none;
                border: none;
                color: white;
                cursor: pointer;
                width: 24px;
                height: 24px;
                border-radius: 50%;
                display: flex;
                justify-content: center;
                align-items: center;
            }
            
            .chat-controls button:hover {
                background-color: rgba(255, 255, 255, 0.2);
            }
            
            .topic-buttons-container {
                display: flex;
                flex-wrap: wrap;
                gap: 8px;
                padding: 10px;
                background-color: #f8f9fa;
                border-bottom: 1px solid #e9e9eb;
            }
            
            .topic-button {
                flex: 1;
                min-width: calc(50% - 8px);
                background-color: white;
                border: 1px solid #ddd;
                border-radius: 8px;
                padding: 10px;
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 5px;
                cursor: pointer;
                transition: all 0.2s ease;
            }
            
            .topic-button i {
                font-size: 20px;
                color: #3498db;
            }
            
            .topic-button:hover {
                background-color: #f1f1f1;
                transform: translateY(-2px);
                box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            }
            
            .topic-menu {
                background-color: white;
                border-radius: 8px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                position: absolute;
                z-index: 1000;
                width: 250px;
                padding: 10px 0;
                display: none;
            }
            
            .topic-menu.visible {
                display: block;
            }
            
            .topic-menu-item {
                padding: 8px 15px;
                cursor: pointer;
                transition: background-color 0.2s;
                display: flex;
                align-items: center;
                gap: 8px;
            }
            
            .topic-menu-item:hover {
                background-color: #f1f1f1;
            }
            
            .topic-menu-item i {
                color: #3498db;
                width: 20px;
                text-align: center;
            }
            
            .chat-messages {
                flex: 1;
                padding: 15px;
                overflow-y: auto;
                background-color: #f8f9fa;
            }
            
            .chat-message {
                margin-bottom: 15px;
                display: flex;
                flex-direction: column;
                max-width: 80%;
            }
            
            .chat-message.user-message {
                align-self: flex-end;
                align-items: flex-end;
                margin-left: auto;
            }
            
            .chat-message.bot-message {
                align-self: flex-start;
                align-items: flex-start;
                margin-right: auto;
            }
            
            .message-content {
                padding: 10px 15px;
                border-radius: 18px;
                word-break: break-word;
                line-height: 1.4;
            }
            
            .user-message .message-content {
                background-color: #3498db;
                color: white;
                border-top-right-radius: 4px;
            }
            
            .bot-message .message-content {
                background-color: #e9e9eb;
                color: #333;
                border-top-left-radius: 4px;
            }
            
            .message-time {
                font-size: 0.7rem;
                color: #888;
                margin-top: 5px;
            }
            
            .chat-input-container {
                padding: 10px;
                display: flex;
                gap: 10px;
                background-color: white;
                border-top: 1px solid #e9e9eb;
            }
            
            #chat-input {
                flex: 1;
                padding: 10px;
                border: 1px solid #ddd;
                border-radius: 20px;
                resize: none;
                height: 40px;
                max-height: 120px;
                font-family: inherit;
            }
            
            #chat-send {
                width: 40px;
                height: 40px;
                border-radius: 50%;
                background-color: #3498db;
                color: white;
                border: none;
                cursor: pointer;
                display: flex;
                justify-content: center;
                align-items: center;
            }
            
            #chat-send:hover {
                background-color: #2980b9;
            }
            
            .chat-suggestions {
                padding: 10px;
                display: flex;
                gap: 8px;
                flex-wrap: wrap;
                background-color: white;
                border-top: 1px solid #e9e9eb;
            }
            
            .suggestion-chip {
                background-color: #f1f1f1;
                border: none;
                border-radius: 16px;
                padding: 6px 12px;
                font-size: 0.8rem;
                cursor: pointer;
                white-space: nowrap;
            }
            
            .suggestion-chip:hover {
                background-color: #e1e1e1;
            }
            
            .typing-indicator {
                display: flex;
                align-items: center;
                gap: 5px;
                padding: 10px 15px;
                background-color: #e9e9eb;
                border-radius: 18px;
                border-top-left-radius: 4px;
                max-width: fit-content;
            }
            
            .typing-dot {
                width: 8px;
                height: 8px;
                background-color: #888;
                border-radius: 50%;
                animation: typingAnimation 1.5s infinite ease-in-out;
            }
            
            .typing-dot:nth-child(1) {
                animation-delay: 0s;
            }
            
            .typing-dot:nth-child(2) {
                animation-delay: 0.2s;
            }
            
            .typing-dot:nth-child(3) {
                animation-delay: 0.4s;
            }
            
            @keyframes typingAnimation {
                0%, 100% { transform: translateY(0); }
                50% { transform: translateY(-5px); }
            }
            
            @media (max-width: 768px) {
                #chat-container {
                    width: 100%;
                    height: 70vh;
                    bottom: 0;
                    right: 0;
                    border-radius: 0;
                }
                
                .chat-closed {
                    transform: translateY(100%);
                }
            }
        `;
        
        document.head.appendChild(styleEl);
    }
    
    setupEventListeners() {
        // Toggle chatbot visibility
        document.getElementById('chat-button').addEventListener('click', () => this.toggleChat());
        
        // Close chatbot
        document.getElementById('chat-close').addEventListener('click', () => this.closeChat());
        
        // Minimize chatbot
        document.getElementById('chat-minimize').addEventListener('click', () => this.closeChat());
        
        // Send message on button click
        document.getElementById('chat-send').addEventListener('click', () => this.sendMessage());
        
        // Send message on Enter key (but allow new lines with Shift+Enter)
        document.getElementById('chat-input').addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
        
        // Handle suggestion chips
        document.querySelectorAll('.suggestion-chip').forEach(chip => {
            chip.addEventListener('click', () => {
                const query = chip.getAttribute('data-query');
                document.getElementById('chat-input').value = query;
                this.sendMessage();
            });
        });
        
        // Handle topic buttons
        this.setupTopicButtons();
    }
    
    setupTopicButtons() {
        // Set up attack types button
        document.getElementById('attack-types').addEventListener('click', () => {
            this.handleTopicButtonClick('attack-types');
        });
        
        // Set up security basics button
        document.getElementById('security-basics').addEventListener('click', () => {
            this.handleTopicButtonClick('security-basics');
        });
        
        // Set up model explanation button
        document.getElementById('model-explain').addEventListener('click', () => {
            this.handleTopicButtonClick('model-explain');
        });
        
        // Set up troubleshooting button
        document.getElementById('troubleshoot').addEventListener('click', () => {
            this.handleTopicButtonClick('troubleshoot');
        });
    }
    
    handleTopicButtonClick(topicId) {
        let message = '';
        
        switch(topicId) {
            case 'attack-types':
                message = "What types of network attacks can this system detect?";
                break;
            case 'security-basics':
                message = "What are the basic network security best practices?";
                break;
            case 'model-explain':
                message = "How does the intrusion detection model work?";
                break;
            case 'troubleshoot':
                message = "What should I do if I get a false positive alert?";
                break;
        }
        
        // Set the message in the input field
        document.getElementById('chat-input').value = message;
        
        // Send the message
        this.sendMessage();
    }
    
    toggleChat() {
        this.isOpen = !this.isOpen;
        const chatContainer = document.getElementById('chat-container');
        
        if (this.isOpen) {
            chatContainer.classList.remove('chat-closed');
            chatContainer.classList.add('chat-open');
            document.getElementById('chat-input').focus();
        } else {
            chatContainer.classList.remove('chat-open');
            chatContainer.classList.add('chat-closed');
        }
    }
    
    openChat() {
        this.isOpen = true;
        const chatContainer = document.getElementById('chat-container');
        chatContainer.classList.remove('chat-closed');
        chatContainer.classList.add('chat-open');
        document.getElementById('chat-input').focus();
    }
    
    closeChat() {
        this.isOpen = false;
        const chatContainer = document.getElementById('chat-container');
        chatContainer.classList.remove('chat-open');
        chatContainer.classList.add('chat-closed');
    }
    
    sendMessage() {
        const inputElement = document.getElementById('chat-input');
        const message = inputElement.value.trim();
        
        if (!message || this.isLoading) return;
        
        // Add user message to chat
        this.addMessage('user', message);
        
        // Clear input
        inputElement.value = '';
        
        // Show typing indicator
        this.showTypingIndicator();
        
        // Process the message and get a response
        this.processMessage(message);
    }
    
    processMessage(message) {
        this.isLoading = true;
        
        // Call the API endpoint
        fetch('/chatbot', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ message: message })
        })
        .then(response => response.json())
        .then(data => {
            // Hide typing indicator
            this.hideTypingIndicator();
            
            // Add response to chat
            if (data.status === 'success') {
                this.addMessage('bot', data.response);
            } else {
                this.addMessage('bot', "I'm sorry, I encountered an error processing your request. Please try again.");
                console.error('Chatbot API error:', data.error);
            }
            
            this.isLoading = false;
        })
        .catch(error => {
            this.hideTypingIndicator();
            this.addMessage('bot', "I'm sorry, I encountered an error connecting to the server. Please try again later.");
            console.error('Chatbot fetch error:', error);
            this.isLoading = false;
        });
    }
    
    generateResponse(message) {
        // Simple keyword-based responses
        message = message.toLowerCase();
        
        if (message.includes('hello') || message.includes('hi') || message.includes('hey')) {
            return "Hello! How can I help with your network security today?";
        }
        
        if (message.includes('what is an ids') || message.includes('intrusion detection')) {
            return "An Intrusion Detection System (IDS) is a security technology that monitors network traffic and system activities for malicious activities or policy violations. Our system uses deep learning algorithms trained on the NSL-KDD dataset to identify potential network intrusions by analyzing patterns in network traffic data.";
        }
        
        if (message.includes('explain alert') || message.includes('latest alert')) {
            return "The most recent alert was triggered because the system detected unusual network traffic patterns that match known attack signatures. This could indicate a potential intrusion attempt. You can check the details in the main dashboard to see which specific features triggered the alert.";
        }
        
        if (message.includes('interpret model') || message.includes('explain model')) {
            return "Our model uses SHAP (SHapley Additive exPlanations) values to explain predictions. The explainability page shows which features most influenced the model's decision. Red areas on the charts indicate features that pushed the prediction toward 'malicious', while blue areas show features that suggested 'normal' traffic. You can visit the explainability page to see detailed visualizations.";
        }
        
        if (message.includes('security tips') || message.includes('best practices')) {
            return "Here are some network security best practices:\n• Keep all systems and software updated\n• Use strong, unique passwords and enable 2FA where possible\n• Segment your network to limit breach impact\n• Implement proper firewall rules\n• Monitor network traffic for unusual patterns\n• Regularly backup important data\n• Train users to recognize phishing and social engineering attacks";
        }
        
        if (message.includes('model') || message.includes('algorithm') || message.includes('how does it work')) {
            return "Our system uses a Deep Neural Network trained on the NSL-KDD dataset, which contains labeled network traffic data. The model analyzes multiple features of network connections, such as protocol type, service, duration, source and destination bytes, and connection patterns. It identifies potential intrusions by finding anomalies and patterns similar to known attacks.";
        }
        
        if (message.includes('false positive') || message.includes('false alarm')) {
            return "False positives can occur in any detection system. If you believe an alert is a false positive, you can mark it as such in the system. This feedback helps improve model accuracy over time. Consider investigating why it might have triggered - sometimes legitimate but unusual traffic can be flagged.";
        }
        
        if (message.includes('thank')) {
            return "You're welcome! Let me know if you have any other questions about network security or our intrusion detection system.";
        }
        
        // Default response
        return "I'm here to help with network security questions. You can ask about how the IDS works, how to interpret alerts, security best practices, or understanding the model's explanations. What would you like to know more about?";
    }
    
    addMessage(sender, content) {
        const messagesContainer = document.getElementById('chat-messages');
        const messageElement = document.createElement('div');
        
        messageElement.className = `chat-message ${sender}-message`;
        
        // Current time
        const now = new Date();
        const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        messageElement.innerHTML = `
            <div class="message-content">${this.formatMessage(content)}</div>
            <div class="message-time">${timeString}</div>
        `;
        
        messagesContainer.appendChild(messageElement);
        
        // Scroll to bottom
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        
        // Save to history
        this.messageHistory.push({
            sender: sender,
            content: content,
            timestamp: now
        });
    }
    
    formatMessage(content) {
        // Convert URLs to links
        let formatted = content.replace(
            /(https?:\/\/[^\s]+)/g, 
            '<a href="$1" target="_blank">$1</a>'
        );
        
        // Convert newlines to <br>
        formatted = formatted.replace(/\n/g, '<br>');
        
        return formatted;
    }
    
    showTypingIndicator() {
        const messagesContainer = document.getElementById('chat-messages');
        const typingIndicator = document.createElement('div');
        typingIndicator.id = 'typing-indicator';
        typingIndicator.className = 'typing-indicator';
        typingIndicator.innerHTML = `
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
        `;
        
        messagesContainer.appendChild(typingIndicator);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
    
    hideTypingIndicator() {
        const typingIndicator = document.getElementById('typing-indicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }
}

// Initialize the chatbot when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.securityChatbot = new SecurityChatbot();
    window.securityChatbot.init();
}); 